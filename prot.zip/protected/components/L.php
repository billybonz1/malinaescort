<?php
// Language alias
class L{
    public static function t($message){
        return YII::t('lang',$message);
    }
}