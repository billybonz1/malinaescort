<?php
class Contact extends CWidget
{
    public function init()
    {

    }

    public function run()
    {
        $this->render('ContactView');
    }
}