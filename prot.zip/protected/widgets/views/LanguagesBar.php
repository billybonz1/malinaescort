<?php $sn=$_SERVER['SERVER_NAME'];
$path=parse_url($_SERVER['REQUEST_URI'])['path'];?>
<?php if($this->controller->getM()):?>
    <ul class="language-nav">
        <?php  foreach($list as $lang):
            $prefix=$lang!='ru'?$lang.'.':'';
            if( explode('.',$_SERVER['SERVER_NAME'])[0]=='m')
            {
                $link = 'm.'.$prefix.(strlen(explode('.',$sn)[1])==2 ? substr($sn,5) : substr($sn,2));
            }
            else
            {
                $link = $prefix.(strlen(explode('.',$sn)[0])==2 ? substr($sn,3) : $sn);
            }
            $langs=[
                'ru'=>'RU',
                'ua'=>'UA',
                'pl'=>'PL',
                'en'=>'EN',
                'tr'=>'TR',
            ]
            ?>

            <li><a class="language-nav__link" title="<?=$lang?>" href="https://<?php echo $link.$path?>"><?=$langs[$lang]?></a></li>
        <?php endforeach;?>
    </ul><!--/.country-list-->

<?php else:?>
    <div class="pull-left">
        <ul class="country-list">
            <?php  foreach($list as $lang):
                $prefix=$lang!='ru'?$lang.'.':'';
                $link = $prefix.(strlen(explode('.',$sn)[0])==2 ? substr($sn,3) : $sn);
                ?>
                <li><a class="icon-<?=$lang?>" title="<?=$lang?>" href="https://<?php echo $link.$path?>"></a></li>
            <?php endforeach;?>
        </ul><!--/.country-list-->
    </div>
<?php endif?>
