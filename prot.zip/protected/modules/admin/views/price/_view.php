<?php
/* @var $this PriceController */
/* @var $data Price */
?>

<tr><td><?php echo CHtml::encode($data->days); ?></td></tr>
<tr><td><?php echo CHtml::encode($data->price); ?></td></tr>
<tr><td><?php echo CHtml::encode($data->price_vip); ?></td></tr>