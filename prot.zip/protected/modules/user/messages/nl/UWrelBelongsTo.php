<?php

return array(
	'Model Name'=>'Modelnaam',
	'Lable field name'=>'Lable veldnamen',
	'Empty item name'=>'Leeg item-naam',
	'Profile model relation name'=>'Profiel model relatienaam',
);
