<?php
/* @var $this SiteController */
/* @var $error array */

$this->pageTitle=C::i('site_title') . ' - Error';
$this->breadcrumbs=array(
    'Error',
);
?>
<div class="error_img"></div>
<div class="error_text">
<h2><?=L::t('Sorry, this page does not exist!');?></h2>
    <?=CHtml::link(L::t('Let us go home?'),$bu.'/',array('class'=>'logo'));?>
</div>
<br/>