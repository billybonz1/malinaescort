User-agent: *
Disallow: /search
Disallow: /*?
Host: <?php echo "$host\n"; ?>
Sitemap: <?php echo "$sitemap\n"; ?>