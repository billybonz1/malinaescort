<h1><?=$content->name?></h1>
<div id="content" class="content"><?=$content->text?></div>