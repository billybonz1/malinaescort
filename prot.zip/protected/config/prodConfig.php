<?php
return array(
    'connectionString' => 'mysql:host=localhost;dbname=vippopki_malinaescort',
    'emulatePrepare' => true,
    'username' => 'vippopki_malinaescort',
    'password' => '6^CDVEHCgsx~',
    'charset' => 'utf8',
    'tablePrefix' => ''
);
//return array(
//    'connectionString' => 'mysql:host=localhost;dbname=forms_db',
//    'emulatePrepare' => true,
//    'username' => 'root',
//    'password' => 'z1866mpXEP56339',
//    'charset' => 'utf8',
//    'tablePrefix' => ''
//);
